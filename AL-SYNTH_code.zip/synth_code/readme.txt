

IJCAI-2022 Supplemental Material Code for:

	"Dataset Augmentation in Papyrology with Generative Models:A Study of Synthetic Ancient Greek Character Images"

	By: 	Matthew I. Swindall1 , Timothy Player2 , Ben Keener3 , Alex C. Williams8∗ ,James H. Brusuelas3 , 
		Federica Nicolardi4 , Marzia D’Angelo5 ,Claudio Vergara6 , Michael McOsker7 and John F. Wallin1


All synthetic images were generated on an Ubunt 18.04.4 LTS (Bionic Beaver) server with Intel Core i9 9820X with 64 GB RAM, and 2
NVIDIA GeForce RTX 2080 Ti GPUs with 11 GB GDDR6 memory. 

To install the Python 3.7 virtual environment and all necessary libraries including stylegan2_pytorch, simply run setup.sh.

Once the environment has been installed, you can begin generating synthetic images using generate.sh. This script takes 3 
commandline arguments; path to training images, chosen name for model, and path to where you want the images saved.

	Example:	./generate.sh /MyHomeDirectory/MyImageDirectory MyModelName /MyHomeDirectory/MyResultsDirectory

The publicly available AL-PUB dataset can be downloaded at https://data.cs.mtsu.edu/al-pub/ and can be downloaded directly
in your linux terminal using one of the following commands depending on your preferred compression format:

	wget https://data.cs.mtsu.edu/al-pub/ALPUB.zip
	wget https://data.cs.mtsu.edu/al-pub/ALPUB.tar.gz

All output from image and model generation are directed to nohup.out for review and debugging. Once the results are to your
liking, you can shut down the process with the command "pkill python" if you have no other python scripts running, or your 
preferred method for shutting down python processes. 

For more information on the CNN and ResNet classification models, please visit https://github.com/mis2n/synthGUI


