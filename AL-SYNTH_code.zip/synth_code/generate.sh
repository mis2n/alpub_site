#!/bin/bash
source env37/bin/activate

nohup stylegan2_pytorch --data $1 --multi-gpus --name $2 --results_dir $3 --aug-prob 0.5 --attn-layers 1 &
