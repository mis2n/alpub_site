#!/bin/bash
echo "Creating Python 3.7 Virtual environment"
python3 -m venv env37
echo "Activating Virtual Environment"
source env37/bin/activate
echo "Updating pip"
python3 -m pip install --upgrade pip
echo ""
echo "Installing Necessary Libraries . . . . ."
echo ""
echo "This may take a while . . . . . "
echo ""
pip install -r env37_requirements.txt
echo "Installing Pytorch's StyleGAN2"
pip install stylegan2_pytorch
deactivate
echo "All components installed"
echo "You are now ready to generate synthetic images"

